package com.tao.dich

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val info = TextView(this).apply {
            textSize = 16f
            text = "Cách bật:\n\n" +
                "1. Bấm \"Mở cài đặt Trợ năng\", chọn \"Dịch Taobao\" rồi bật.\n\n" +
                "2. Nếu máy báo \"Cài đặt bị hạn chế\": bấm \"Mở thông tin ứng dụng\", bấm dấu ba chấm góc trên, " +
                "chọn \"Cho phép cài đặt bị hạn chế\", rồi làm lại bước 1.\n\n" +
                "3. Mở Taobao: bong bóng \"Dịch\" tự hiện. Bấm để dịch, bấm \"Gốc\" để trở lại. " +
                "Ra khỏi app mua sắm thì bong bóng tự ẩn.\n\n" +
                "Cần có mạng khi dịch. Không ảnh hưởng chia sẻ màn hình Discord."
        }
        val b1 = Button(this).apply {
            text = "Mở cài đặt Trợ năng"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val b2 = Button(this).apply {
            text = "Mở thông tin ứng dụng"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        }
        root.addView(info)
        root.addView(b1)
        root.addView(b2)
        setContentView(root)
    }
}
