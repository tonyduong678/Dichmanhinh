package com.tao.dich

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class TranslateService : AccessibilityService() {

    companion object {
        private val HAN = Regex("[\\u4e00-\\u9fff]")
        private val SHOP_PKGS = setOf(
            "com.taobao.taobao", "com.taobao.litetao", "com.tmall.wireless",
            "com.taobao.idlefish", "com.alibaba.wireless",
            "com.xunmeng.pinduoduo", "com.jingdong.app.mall"
        )
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var overlay: TranslationOverlayView? = null
    private var busy = false
    private var inShop = true
    private var stage = ""
    private val watchdog = Runnable { fail("Kẹt ở bước: $stage. Kiểm tra mạng rồi thử lại") }

    private val recognizer by lazy {
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    }
    private val pool = Executors.newFixedThreadPool(6)

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubble()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (pkg in SHOP_PKGS) {
            inShop = true
            if (!busy) bubble?.visibility = View.VISIBLE
        } else if (pkg == "com.android.systemui" || pkg.contains("inputmethod") || pkg.contains("keyboard")) {
            // bàn phím, thanh thông báo: giữ nguyên trạng thái
        } else {
            inShop = false
            removeOverlay()
            if (!busy) {
                setLabel("Dịch")
                bubble?.visibility = View.GONE
            }
        }
    }

    private fun addBubble() {
        val d = resources.displayMetrics.density
        val size = (54 * d).toInt()
        val tv = TextView(this).apply {
            text = "Dịch"
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE6FF5000.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * d).toInt()
            y = resources.displayMetrics.heightPixels / 3
        }
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (moved || Math.abs(dx) > 12 || Math.abs(dy) > 12) {
                        moved = true
                        lp.x = (ox + dx).toInt()
                        lp.y = (oy + dy).toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onBubbleClick()
                }
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
        bubbleLp = lp
    }

    private fun onBubbleClick() {
        if (busy) return
        if (overlay != null) {
            removeOverlay()
            setLabel("Dịch")
            return
        }
        busy = true
        stage = "chụp màn hình"
        setLabel("...")
        bubble?.visibility = View.INVISIBLE
        main.removeCallbacks(watchdog)
        main.postDelayed(watchdog, 90000)
        // chờ bong bóng biến mất khỏi khung hình rồi mới chụp
        main.postDelayed({ shot() }, 350)
    }

    private fun shot() {
        takeScreenshot(
            Display.DEFAULT_DISPLAY, mainExecutor,
            object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    try {
                        val hb = result.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                        val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                        hb.close()
                        if (bmp == null) fail("Không đọc được ảnh chụp") else onFrame(bmp)
                    } catch (e: Exception) {
                        fail("Lỗi ảnh chụp: ${e.message}")
                    }
                }

                override fun onFailure(errorCode: Int) {
                    fail("Không chụp được (mã $errorCode). Đợi 1-2 giây rồi bấm lại")
                }
            }
        )
    }

    private fun onFrame(bmp: Bitmap) {
        stage = "nhận diện chữ"
        refreshBubble()
        setLabel("OCR")
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { res ->
                val src = res.textBlocks
                    .flatMap { it.lines }
                    .filter { it.boundingBox != null && HAN.containsMatchIn(it.text) }
                    .map { Pair(Rect(it.boundingBox!!), it.text) }
                if (src.isEmpty()) {
                    bmp.recycle()
                    fail("Không thấy chữ Trung nào")
                } else {
                    translateAll(bmp, src)
                }
            }
            .addOnFailureListener {
                bmp.recycle()
                fail("OCR lỗi: ${it.message}")
            }
    }

    private fun translateAll(bmp: Bitmap, src: List<Pair<Rect, String>>) {
        stage = "dịch chữ (cần mạng)"
        setLabel("...")
        val out = arrayOfNulls<String>(src.size)
        val left = AtomicInteger(src.size)
        src.forEachIndexed { i, pair ->
            pool.execute {
                out[i] = try {
                    googleTranslate(pair.second)
                } catch (e: Exception) {
                    null
                }
                if (left.decrementAndGet() == 0) {
                    main.post { showOverlay(bmp, src, out) }
                }
            }
        }
    }

    private fun googleTranslate(text: String): String? {
        val url = URL(
            "https://translate.googleapis.com/translate_a/single?client=gtx&sl=zh-CN&tl=vi&dt=t&q=" +
                URLEncoder.encode(text, "UTF-8")
        )
        val c = url.openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (c.responseCode != 200) return null
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(body).getJSONArray(0)
            val sb = StringBuilder()
            for (k in 0 until arr.length()) sb.append(arr.getJSONArray(k).optString(0))
            val r = sb.toString()
            return if (r.isBlank()) null else r
        } finally {
            c.disconnect()
        }
    }

    private fun sampleBg(b: Bitmap, r: Rect): Int {
        val pts = listOf(
            Pair(r.left + 2, r.top + 2), Pair(r.right - 2, r.top + 2),
            Pair(r.left + 2, r.bottom - 2), Pair(r.right - 2, r.bottom - 2)
        )
        var rs = 0
        var gs = 0
        var bs = 0
        var n = 0
        for (pt in pts) {
            if (pt.first in 0 until b.width && pt.second in 0 until b.height) {
                val c = b.getPixel(pt.first, pt.second)
                rs += Color.red(c); gs += Color.green(c); bs += Color.blue(c); n++
            }
        }
        return if (n == 0) Color.WHITE else Color.rgb(rs / n, gs / n, bs / n)
    }

    private fun showOverlay(bmp: Bitmap, src: List<Pair<Rect, String>>, out: Array<String?>) {
        main.removeCallbacks(watchdog)
        try {
            showOverlayInner(bmp, src, out)
        } catch (e: Exception) {
            fail("Lỗi hiển thị: ${e.message}")
        }
    }

    private fun showOverlayInner(bmp: Bitmap, src: List<Pair<Rect, String>>, out: Array<String?>) {
        val w = bmp.width
        val h = bmp.height
        val items = ArrayList<TranslationOverlayView.Item>()
        src.forEachIndexed { i, pair ->
            val t = out[i]
            if (t != null) {
                val r = Rect(pair.first)
                r.inset(-2, -1)
                val bg = sampleBg(bmp, r)
                val lum = 0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)
                items.add(TranslationOverlayView.Item(r, t, bg, if (lum > 140) Color.BLACK else Color.WHITE))
            }
        }
        bmp.recycle()
        if (items.isEmpty()) {
            fail("Dịch thất bại, kiểm tra mạng rồi thử lại")
            return
        }

        val v = TranslationOverlayView(this)
        v.setItems(items)
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        wm.addView(v, lp)
        overlay = v

        // đưa bong bóng lên trên lớp dịch
        bubble?.let { b ->
            try {
                wm.removeView(b)
                b.visibility = View.VISIBLE
                wm.addView(b, bubbleLp)
            } catch (_: Exception) {
            }
        }
        setLabel("Gốc")
        busy = false
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
    }

    private fun refreshBubble() {
        bubble?.visibility = if (inShop) View.VISIBLE else View.GONE
    }

    private fun setLabel(s: String) {
        bubble?.text = s
    }

    private fun fail(msg: String) {
        main.removeCallbacks(watchdog)
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        busy = false
        refreshBubble()
        setLabel("Dịch")
    }

    override fun onDestroy() {
        removeOverlay()
        bubble?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        bubble = null
        pool.shutdownNow()
        recognizer.close()
        super.onDestroy()
    }
}
