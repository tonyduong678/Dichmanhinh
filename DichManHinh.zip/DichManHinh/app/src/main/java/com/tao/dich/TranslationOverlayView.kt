package com.tao.dich

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

class TranslationOverlayView(ctx: Context) : View(ctx) {

    class Item(val rect: Rect, val text: String, val bg: Int, val fg: Int)

    private var items: List<Item> = emptyList()
    private val bgPaint = Paint()
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)

    fun setItems(list: List<Item>) {
        items = list
        invalidate()
    }

    private fun build(text: String, size: Float, width: Int): StaticLayout {
        textPaint.textSize = size
        return StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .build()
    }

    override fun onDraw(canvas: Canvas) {
        val minSize = 9f * resources.displayMetrics.density
        for (item in items) {
            bgPaint.color = item.bg
            canvas.drawRect(item.rect, bgPaint)
            textPaint.color = item.fg
            val w = maxOf(item.rect.width(), 1)
            val h = item.rect.height()
            var size = h * 0.8f
            var layout = build(item.text, size, w)
            while (layout.height > h && size > minSize) {
                size -= 1.5f
                layout = build(item.text, size, w)
            }
            canvas.save()
            canvas.translate(item.rect.left.toFloat(), item.rect.top.toFloat())
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
