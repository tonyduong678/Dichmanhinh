package com.tao.dich

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions

class OverlayService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "com.tao.dich.STOP"
        private const val CHANNEL = "dich"
        private const val NOTI_ID = 1
        private val HAN = Regex("[\\u4e00-\\u9fff]")
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var vDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var imgThread: HandlerThread? = null
    private var imgHandler: Handler? = null
    private val lock = Any()
    private var held: Image? = null

    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var overlay: TranslationOverlayView? = null
    private var busy = false
    private var stage = ""
    private val watchdog = Runnable { fail("Kẹt ở bước: $stage. Kiểm tra mạng rồi thử lại") }
    private var screenW = 0
    private var screenH = 0
    private var dpi = 0

    private val recognizer by lazy {
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    }
    private val translator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.CHINESE)
                .setTargetLanguage(TranslateLanguage.VIETNAMESE)
                .build()
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY
        startFg()
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        setupCapture()
        addBubble()
        warmUpTranslator()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Dịch màn hình", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Dịch màn hình đang chạy")
            .setContentText("Bấm Tắt để dừng")
            .addAction(android.R.drawable.ic_delete, "Tắt", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTI_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTI_ID, n)
        }
    }

    private fun realSize() {
        val dm = resources.displayMetrics
        dpi = dm.densityDpi
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            screenW = b.width()
            screenH = b.height()
        } else {
            val r = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(r)
            screenW = r.widthPixels
            screenH = r.heightPixels
        }
    }

    private fun setupCapture() {
        realSize()
        imgThread = HandlerThread("img").also { it.start() }
        imgHandler = Handler(imgThread!!.looper)
        val rd = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 3)
        reader = rd
        rd.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage()
            if (img != null) {
                synchronized(lock) {
                    held?.close()
                    held = img
                }
            }
        }, imgHandler)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)
        vDisplay = projection!!.createVirtualDisplay(
            "dich", screenW, screenH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, null
        )
    }

    private fun warmUpTranslator() {
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnFailureListener {
                toast("Chưa tải được model dịch, kiểm tra mạng: ${it.message}")
            }
    }

    private fun addBubble() {
        val d = resources.displayMetrics.density
        val size = (54 * d).toInt()
        val tv = TextView(this).apply {
            text = "Dịch"
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE6FF5000.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * d).toInt()
            y = screenH / 3
        }
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (moved || Math.abs(dx) > 12 || Math.abs(dy) > 12) {
                        moved = true
                        lp.x = (ox + dx).toInt()
                        lp.y = (oy + dy).toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onBubbleClick()
                }
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
        bubbleLp = lp
    }

    private fun onBubbleClick() {
        if (busy) return
        if (overlay != null) {
            removeOverlay()
            setLabel("Dịch")
            return
        }
        busy = true
        stage = "chụp màn hình"
        setLabel("...")
        bubble?.visibility = View.INVISIBLE
        main.removeCallbacks(watchdog)
        main.postDelayed(watchdog, 90000)
        // chờ bong bóng biến mất khỏi khung hình rồi mới lấy ảnh
        main.postDelayed({ grab() }, 300)
    }

    private fun grab() {
        imgHandler?.post {
            var bmp: Bitmap? = null
            try {
                synchronized(lock) {
                    held?.let { bmp = toBitmap(it) }
                }
            } catch (_: Exception) {
            }
            main.post {
                val b = bmp
                if (b == null) fail("Chưa chụp được màn hình") else onFrame(b)
            }
        }
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val rowPixels = p.rowStride / p.pixelStride
        val full = Bitmap.createBitmap(rowPixels, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        full.copyPixelsFromBuffer(p.buffer)
        if (rowPixels == img.width) return full
        val cropped = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        full.recycle()
        return cropped
    }

    private fun onFrame(bmp: Bitmap) {
        stage = "nhận diện chữ"
        bubble?.visibility = View.VISIBLE
        setLabel("OCR")
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { res ->
                val src = res.textBlocks
                    .flatMap { it.lines }
                    .filter { it.boundingBox != null && HAN.containsMatchIn(it.text) }
                    .map { Pair(Rect(it.boundingBox!!), it.text) }
                if (src.isEmpty()) {
                    bmp.recycle()
                    fail("Không thấy chữ Trung nào")
                } else {
                    translateAll(bmp, src)
                }
            }
            .addOnFailureListener {
                bmp.recycle()
                fail("OCR lỗi: ${it.message}")
            }
    }

    private fun translateAll(bmp: Bitmap, src: List<Pair<Rect, String>>) {
        stage = "tải model dịch (lần đầu cần mạng, có thể 1-2 phút)"
        setLabel("Tải")
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                stage = "dịch chữ"
                setLabel("...")
                val out = arrayOfNulls<String>(src.size)
                var left = src.size
                src.forEachIndexed { i, pair ->
                    translator.translate(pair.second).addOnCompleteListener { task ->
                        out[i] = if (task.isSuccessful) task.result else null
                        left--
                        if (left == 0) showOverlay(bmp, src, out)
                    }
                }
            }
            .addOnFailureListener {
                bmp.recycle()
                fail("Chưa có model dịch (cần mạng lần đầu): ${it.message}")
            }
    }

    private fun sampleBg(b: Bitmap, r: Rect): Int {
        val pts = listOf(
            Pair(r.left + 2, r.top + 2), Pair(r.right - 2, r.top + 2),
            Pair(r.left + 2, r.bottom - 2), Pair(r.right - 2, r.bottom - 2)
        )
        var rs = 0
        var gs = 0
        var bs = 0
        var n = 0
        for (pt in pts) {
            if (pt.first in 0 until b.width && pt.second in 0 until b.height) {
                val c = b.getPixel(pt.first, pt.second)
                rs += Color.red(c); gs += Color.green(c); bs += Color.blue(c); n++
            }
        }
        return if (n == 0) Color.WHITE else Color.rgb(rs / n, gs / n, bs / n)
    }

    private fun showOverlay(bmp: Bitmap, src: List<Pair<Rect, String>>, out: Array<String?>) {
        main.removeCallbacks(watchdog)
        try {
            showOverlayInner(bmp, src, out)
        } catch (e: Exception) {
            fail("Lỗi hiển thị: ${e.message}")
        }
    }

    private fun showOverlayInner(bmp: Bitmap, src: List<Pair<Rect, String>>, out: Array<String?>) {
        val items = ArrayList<TranslationOverlayView.Item>()
        src.forEachIndexed { i, pair ->
            val t = out[i]
            if (t != null) {
                val r = Rect(pair.first)
                r.inset(-2, -1)
                val bg = sampleBg(bmp, r)
                val lum = 0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)
                items.add(TranslationOverlayView.Item(r, t, bg, if (lum > 140) Color.BLACK else Color.WHITE))
            }
        }
        bmp.recycle()
        if (items.isEmpty()) {
            fail("Dịch thất bại (model dịch chưa sẵn sàng?)")
            return
        }

        val v = TranslationOverlayView(this)
        v.setItems(items)
        val lp = WindowManager.LayoutParams(
            screenW, screenH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        wm.addView(v, lp)
        overlay = v

        // đưa bong bóng lên trên lớp dịch
        bubble?.let { b ->
            try {
                wm.removeView(b)
                b.visibility = View.VISIBLE
                wm.addView(b, bubbleLp)
            } catch (_: Exception) {
            }
        }
        setLabel("Gốc")
        busy = false
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
    }

    private fun setLabel(s: String) {
        bubble?.text = s
    }

    private fun fail(msg: String) {
        main.removeCallbacks(watchdog)
        toast(msg)
        busy = false
        bubble?.visibility = View.VISIBLE
        setLabel("Dịch")
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        removeOverlay()
        bubble?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        bubble = null
        vDisplay?.release()
        try {
            projection?.stop()
        } catch (_: Exception) {
        }
        synchronized(lock) {
            held?.close()
            held = null
        }
        reader?.close()
        imgThread?.quitSafely()
        recognizer.close()
        translator.close()
        super.onDestroy()
    }
}
